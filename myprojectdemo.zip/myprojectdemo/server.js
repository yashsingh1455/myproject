require('./dbconnection');
const express = require('express');
const bodyparser = require('body-parser');
const AddNewUser = require('./UserController');
const test=require('./testcontroller');
const game=require('./gamecontroller');
var app = express();





app.use(bodyparser.urlencoded({
    extended: true
}));

app.use(bodyparser.json());


app.use(express.urlencoded({ extended: true }));

     

  


app.listen(process.env.PORT||5000, () => {
    console.log('Express server started at port : 5000');
});



app.use('/api/registration', AddNewUser);
app.use('/api/enter_game',game);
app.use('/test',test);




