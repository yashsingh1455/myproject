var response={
   message:String,
   data:Object,
    status:Number
}
module.exports=response;